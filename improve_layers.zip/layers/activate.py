import numpy as np

class Relu():
    def forward(self, x):
        self.x = x
        return np.maximum(self.x, 0)

    def backward(self, eta):
        eta[self.x <= 0] = 0
        return eta


class sigmoid():
    def forward(self, x):
        self.out = x*(1 / (1 + np.exp(-x)))
        return self.out

    def backward(self, eta):
        sigmoid = 1 / (1 + np.exp(-self.out))
        grad_input = eta * (sigmoid * (1 - sigmoid) + self.out * (1 - sigmoid))
        return grad_input

